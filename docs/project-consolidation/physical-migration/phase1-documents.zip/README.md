# 自主 BIN 引擎 — 專案入口

唯一專案根：`D:\lineage開發\TW1608262200研究`。目前 **P24 / r28**，離線交付已接受，完整同版實機驗收未完成。

- [完整彙整報告（HTML）](docs/project-consolidation/index.html)
- [進度與未完成項](docs/project-consolidation/progress.md)
- [16 路徑盤點](docs/project-consolidation/inventory-report.md)
- [結構／建置契約](docs/project-consolidation/structure.md)
- [遷移批次與下一步](docs/project-consolidation/migration-plan.md)
- [機器可讀專案 manifest](project-manifest.json)

最新固定產品位於 `P24-原2x2地圖快取與跨區載入/reference/development/release-integration-r12/delivery`，正常入口是其中的 `啟動新版客戶端.cmd`。請先讀同目錄使用說明；不要使用 P24 根目錄同名舊入口當作 r28。

原始碼基準是該交付的 `source/`、`audio/`、`web/`；封存包不可原地修改，後續由唯一整合者在隔離工作範圍維護下一版。既有 P01～P24 與主管目錄是研究／驗收歷史。

本輪僅完成索引統一。16 個外部資料夾仍在原地，沒有刪除或搬移；實體整併依遷移批次辦理。既有 AGENTS.md 與主管所有權不因本 README 改變。此整理對話不喚醒舊主管、不派遊戲測試。
