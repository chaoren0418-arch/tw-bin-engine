# 專案結構與入口契約

## 唯一根與當前入口

唯一開發專案根：`D:\lineage開發\TW1608262200研究`。不再按階段建立 D 槽新專案根。其他根路徑視為此專案的外部相依、隔離環境或研究歷史，不視為另一個正在開發的引擎。

下文 `P24` 代表 `P24-原2x2地圖快取與跨區載入`，`R28` 代表 `P24/reference/development/release-integration-r12/delivery`。實際路徑以根目錄 project-manifest.json 為準。

| 角色 | 當前權威位置 | 使用規則 |
|---|---|---|
| 專案入口／彙整 | README.md、project-manifest.json、docs/project-consolidation | 先讀此處，不依資料夾修改日期猜版本 |
| 最新固定產品 | R28 | r28 封存基準；已接受離線交付，完整實機驗收未完成 |
| 原始碼基準 | R28/source、R28/audio、R28/web | 接續改版從此版本派生；不直接修改封存包 |
| 正式啟動 | R28/啟動新版客戶端.cmd | 進 launcher/P24.Launcher.exe，再啟動 build/client-product-r28/P11.ClientEngine.exe --normal-product |
| 素材／套件 | R28/assets、R28/vendor | 與 integrity、product manifest、seal 成套；不能混其他版本素材 |
| 建置產物 | R28/build、R28/launcher | 此版固定產物仍須保留；重建須在副本，並重新產生 launcher 的 manifest 識別 |
| 可變執行資料 | R28/runs、R28/runtime，以及各包的 tmp／SDK cache | 不在固定 seal 內；不能以其修改日期判斷產品升版 |
| 驗收證據 | 主管/P24-本機主管接管與完整整合-20261028 | 主管專有；本輪只讀，舊證據不得混成本版結果 |
| 隔離候選 | P24/reference/development 各具名任務目錄 | 已有候選封存保留；後續每任務指定唯一寫入者，不建多份完整遊戲資料樹 |
| 研究歷史 | P01～P23、P24 的原 reference／腳本及歷代 release-integration | 依來源鏈保存，名稱舊不代表無用 |
| 現用本機服務 | D:\P24Lab-ClientEngine | MySQL／原服／角色保存，服務存活未完整確認；不可搬移或當 cache 清空 |

P24 根目錄的「啟動新版客戶端.cmd」仍呼叫舊 PowerShell launcher，根 build 含 r1～r16 manifest，**不是最新 r28 入口**。本輪保留舊檔，不做隱性重新導向。README 及 manifest 明確指到 r28。

## 建置與啟動需求

正常 r28 啟動需要 Windows x64、.NET 10 Desktop Runtime、WebView2 Runtime；產品固定本機 127.0.0.1:42061、profile p24-real-jar-d287-client2，autoLogin=false，不自啟伺服器。離線預覽不是登入成功。開發建置使用既有 .NET SDK 10.0.300、PowerShell 7、Node、隨附 vendor；主專案 target 為 net10.0-windows，引用 audio/P24.Audio.csproj。

正式重建契約在 R28/_integration/HANDOFF.md：先使用獲授權副本，`seal.py --verify --full` 核對後，以 `_integration/run_stage.py --output <副本內新的 integration evidence 目錄>` 重建產品與 launcher 並執行檢查。單獨 build-product.ps1 會改 manifest；若不更新 launcher 識別，可能啟動檢查失敗。歷史 setup.py／finalize.py 不是可任意再執行的重建入口。

本輪沒有執行上述建置、入口或遊戲測試。這是接續使用說明，不是執行收據。

## 必要外部來源與硬編碼

| 相依 | 現有證據／用途 | 遷移注意 |
|---|---|---|
| D:\lineage開發\0-客戶端 | cache_assets.py 使用 map、Tile.idx、Tile.pak；其他解碼流程使用原素材 | 權威原始資料唯讀保留；封裝包可運行不等於可重新抽取所有素材 |
| D:\lineage開發\登入器bin資源\TW1608262200.bin拆解\TW1608262200.bin | cache_sources.py、archive_dual_sources.py 固定 SHA e12949cf8912c5d62ef269ba02ca37eb5cabf8f379c3d5e10189279bf09641a2 | 原檔與分析 IDB 分開，不刪任何一方；此 SHA 是來源契約，本輪未重新雜湊外部 BIN |
| D:\P24Lab-ClientEngine | prepare.py、lab.py、server.py、SQL／policy 與 IDA 讀取 | DB datadir、43324 port、42061 遊戲 port、程序身份、絕對路徑及服務狀態須一起處理 |
| D:\P23Lab-ClientEngine 及 P10 歷史 | prepare.py 從上一 Lab 複製 MySQL／SQL／server，P10 reference 供 migration schema | 歷史重建依賴；不能因 r28 能啟動就認為全部可刪 |
| D:\P24Lab-6016-Export-r1 | IDA IDB、exports、minimal-contract、操作／身份收據 | 研究來源與已接受契約；整理後仍需查得到原證據 |
| D:\TW1608262200_research | P01、P02、P04～P07 等早期 ASCII 研究／工具輸出 | 不是目前中文權威根的 junction，也不能僅憑名稱認定完整複本 |
| 既有 JDK／IDA／.NET／WebView2 安裝 | lab.py 固定 JDK17 路徑；IDA 輸出及產品 runtime | 記錄版本與安裝相依；不搬工具安裝目錄，不隨文件整理安裝軟體 |

path-dependencies.json 保存文字檔案與行號及命中的絕對路徑；不保存完整行內容，避免把私密設定抄入報告。掃描排除 private、資料庫、可變 runtime、vendor/build 資產本文及大於 2 MiB 的文字；不是完整動態相依圖。父目錄相對引用（例如 R.parents[1]）需隨遷移再單獨檢查。

## 收斂後的目標結構（尚未實體建立／搬移）

```text
TW1608262200研究/
  README.md + project-manifest.json     單一入口與當前版本
  docs/                                架構、進度、契約、遷移紀錄
  engine/                              單一整合者維護的下一版 source/audio/web 與建置設定
  assets/                              權威素材索引及原始來源引用；避免每任務重複完整資產
  environments/p24/                    核實停機後才搬的隔離伺服器與 DB
  releases/r28/                        完整不可變交付；保留自己的 portable assets
  evidence/                            驗收證據與前後資源對帳
  work/<task-id>/                      各任務最小差異、輸出與交接，不複製整套歷史
  history/stages/                      P01～P24 歷史研究／舊交付，保留 provenance
  history/labs/                        P10、P12～P23 舊隔離環境，分清 DB／工具／證據
  history/research/                    ASCII 早期研究、6016 IDA 來源
```

這是遷移後的角色配置，不是本輪建立了一套空目錄。本輪實際只新增文件與清冊，現用位置仍在上表。`engine/` 與 `assets/` 的抽取需先確定 build／封裝不再硬依賴 P24 相對層級；r28 保持完整自含，不將正式包素材改成共享可變連結。
