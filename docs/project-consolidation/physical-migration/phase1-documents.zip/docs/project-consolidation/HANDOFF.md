# 彙整交接

本輪交付：根 README.md、project-manifest.json，及本目錄的 HTML／Markdown 報告與機器清單。新對話「彙整引擎進度與統一專案」是整理執行者，不是第二位開發主管。

狀態是「索引統一完成，實體搬移未執行」。先讀 index.html 或 progress.md，再依 migration-plan.md 決定下一個具體批次。本輪沒有發訊給舊主管／工作者、沒有增開子代理、沒有遊戲／DB／服務操作，也沒有修改正式包或原有入口。舊根與主管 AGENTS.md 保持原樣。

## 已核對

- 16 個外部根都是實體目錄，共 26,929 檔、9.288 GiB；權威根 698,737 檔、約 112.36 GiB。內部 57 個 reparse point 未跟隨。
- 16 根中排除已知可變／私密內容後，13,481 檔 SHA-256；600 組跨根相同本文，1,124 檔在已雜湊 16 根集合內獨有。未做全機唯一性或權威根 112 GiB 全文去重。
- r28 seal、產品 DLL、audio DLL、launcher DLL、product manifest、資產全量核對收據的 SHA 與既有主管接受收據一致。結果在 evidence-index.json；本輪沒有重跑封存包建置或原生遊戲。
- 24,282 個文字檔已掃描，去除 URL 字尾誤判後保留 1,481 筆路徑命中；6 個非 UTF-8 檔未做本文掃描。帶空白、相對父層及拼接字串需依來源檔／行號人工核實，不把命中片段當完整相依圖。
- 現有 native-r28 current-status 比最新對話早；主管最新訊息是在村內路線第 7 步後因模型容量失敗。報告沒有把舊「正在續做」當今日運作狀態。

## 阻礙及已做部分

1. 操作：查詢 Win32_Process；目標：目前本機程序與寫入者。結果：作業系統拒絕存取，非工具自動審批拒絕；沒有改用其他通道重試。本輪已完成對話最近回合與磁碟修改時間查核，但服務／DB 是否仍存活未能完整核實。下一步 B1 必須確認所有權／creation time／port／datadir，才可決策停機與搬移。
2. 操作：建立／讀取整理對話真正 Goal；目標：本對話。結果：工具未提供 get_goal/create_goal，不是成功或待執行中的請求。本輪沒有改 Goal 儲存檔；文件整理照常完成。
3. 本輪沒有提出或嘗試實體搬移。B2～B6 是具體待決策批次，並非被拒後換路徑重試。當前不需要以恢復遊戲驗收來完成文件交接。

## 重跑方法（只在需要刷新盤點時）

所有程式只讀原資料，寫入本 docs 目錄；publish_report.py 另更新根 README 與 project-manifest。執行前核對沒有另一整理者寫相同文件。指令會刷新本輪清冊，不是歷史封存的重建命令。

```powershell
$reportRoot = 'D:\lineage開發\TW1608262200研究\docs\project-consolidation'
python -B -X utf8 "$reportRoot\inventory.py"
python -B -X utf8 "$reportRoot\analyze.py"
python -B -X utf8 "$reportRoot\dependencies.py"
python -B -X utf8 "$reportRoot\summarize_sizes.py"
python -B -X utf8 "$reportRoot\publish_report.py"
```

inventory.py 已改為直接產生壓縮 JSONL；本輪首次盤點曾產生未壓縮中間檔，內容比對後只移除這個本輪自建中間檔，不刪既有專案資料。refine_dependencies.py 是本輪路徑抽取誤判修正收據工具；dependencies.py 已套用修正，重跑不需再次修正。

恢復原狀僅需移除本輪新增 docs/project-consolidation、根 README.md 與 project-manifest.json；不需要恢復 DB、版本或入口。請先留存要保留的報告，且勿在後續已有人更新這些文件後直接照此回復。
